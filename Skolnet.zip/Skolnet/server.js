// server.js
const express = require('express');
const app = express();
const path = require('path');

const PORT = 3000; // Porten vi kör på (localhost:3000)

// Säg åt servern att servera alla filer i den här mappen (CSS, JS, Bilder)
app.use(express.static(__dirname));

// När man går in på startsidan ('/'), skicka index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Starta servern
app.listen(PORT, () => {
    console.log(`🚀 Servern är igång!`);
    console.log(`👉 Gå till: http://localhost:${PORT}`);
    console.log(`   (Tryck Ctrl + C i terminalen för att stoppa servern)`);
});