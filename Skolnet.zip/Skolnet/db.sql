-- WARNING: This schema is for context only and is not meant to be run.
-- Table order and constraints may not be valid for execution.

-- Ligger uppe på supabase och kopplas med API i common.js

CREATE TABLE public.assignments (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  title text,
  description text,
  type text,
  due_date date,
  status text DEFAULT 'published'::text,
  scheduled_for timestamp with time zone,
  attachment_name text,
  course text,
  class_name text,
  created_at timestamp with time zone DEFAULT now(),
  target_students ARRAY,
  attachments jsonb DEFAULT '[]'::jsonb,
  CONSTRAINT assignments_pkey PRIMARY KEY (id)
);
CREATE TABLE public.attendance_records (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  student_name text,
  course text,
  date date,
  status text,
  reason text,
  reported_at timestamp with time zone DEFAULT now(),
  day_of_week text,
  start_time text,
  end_time text,
  room text,
  class_name text,
  is_full_day boolean DEFAULT false,
  CONSTRAINT attendance_records_pkey PRIMARY KEY (id)
);
CREATE TABLE public.course_members (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  course_id bigint,
  user_name text,
  user_class text,
  role text DEFAULT 'student'::text,
  added_at timestamp with time zone DEFAULT now(),
  CONSTRAINT course_members_pkey PRIMARY KEY (id),
  CONSTRAINT course_members_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id)
);
CREATE TABLE public.courses (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  name text,
  teacher text,
  target_class text,
  theme text,
  is_archived boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT courses_pkey PRIMARY KEY (id)
);
CREATE TABLE public.grades (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  student_name text,
  course text,
  grade text,
  feedback text,
  course_warning boolean DEFAULT false,
  graded_at date DEFAULT CURRENT_DATE,
  CONSTRAINT grades_pkey PRIMARY KEY (id)
);
CREATE TABLE public.lunch_menu (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  day text,
  dish text,
  CONSTRAINT lunch_menu_pkey PRIMARY KEY (id)
);
CREATE TABLE public.messages (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  sender_name text,
  content text,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT messages_pkey PRIMARY KEY (id)
);
CREATE TABLE public.notifications (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  user_name text,
  message text,
  link text,
  is_read boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT notifications_pkey PRIMARY KEY (id)
);
CREATE TABLE public.schedule (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  course text,
  day_of_week text,
  start_time text,
  end_time text,
  room text,
  teacher text,
  class_name text,
  CONSTRAINT schedule_pkey PRIMARY KEY (id)
);
CREATE TABLE public.stream_posts (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  course text,
  author_name text,
  content text,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT stream_posts_pkey PRIMARY KEY (id)
);
CREATE TABLE public.submissions (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  assignment_id bigint,
  student_name text,
  status text,
  submitted_at timestamp with time zone DEFAULT now(),
  submitted_file text,
  submission_text text,
  submitted_files jsonb DEFAULT '[]'::jsonb,
  CONSTRAINT submissions_pkey PRIMARY KEY (id),
  CONSTRAINT submissions_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.assignments(id)
);
CREATE TABLE public.task_comments (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  assignment_id bigint,
  user_name text,
  text text,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT task_comments_pkey PRIMARY KEY (id),
  CONSTRAINT task_comments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.assignments(id)
);
CREATE TABLE public.users (
  id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  username text UNIQUE,
  password text,
  name text,
  role text,
  class_name text,
  submission_streak integer DEFAULT 0,
  CONSTRAINT users_pkey PRIMARY KEY (id)
);