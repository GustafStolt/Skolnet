console.log("🚀 LADDAR: student.js (FINAL DOWNLOAD & MULTI-FILE)");

let autoSaveTimer = null;
let selectedFiles = []; // Håller koll på elevens valda filer

// =========================================================
// 1. NAVIGERING
// =========================================================
function initStudentCourseView() { switchCourseTabStudent('stream'); }
window.initStudentCourseView = initStudentCourseView;

function switchCourseTabStudent(tab) {
    ['stream', 'classwork', 'people'].forEach(t => {
        document.getElementById('nav-' + t).className = 'course-nav-item';
        document.getElementById('course-tab-' + t).style.display = 'none';
    });
    document.getElementById('nav-' + tab).classList.add('active');
    document.getElementById('course-tab-' + tab).style.display = 'block';

    if (tab === 'stream') renderStudentStream();
    if (tab === 'classwork') renderStudentClasswork();
    if (tab === 'people') renderStudentPeople();
}
window.switchCourseTabStudent = switchCourseTabStudent;

// =========================================================
// 2. ATT GÖRA
// =========================================================
async function renderTodoList() {
    const container = document.getElementById('list-todo-pending');
    container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';
    let q = _supabase.from('assignments').select('*').neq('status', 'draft');
    const { data: allTasks } = await q;
    const { data: mySubs } = await _supabase.from('submissions').select('*').eq('student_name', currentUser.name);

    if (!allTasks) { container.innerHTML = 'Inga uppgifter.'; return; }
    const now = new Date(); now.setHours(0, 0, 0, 0);
    let missing = [], upcoming = [], done = [];

    allTasks.forEach(t => {
        if (t.target_students && t.target_students.length > 0 && !t.target_students.includes(currentUser.name)) return;
        const sub = mySubs ? mySubs.find(s => s.assignment_id === t.id) : null;
        const isDone = sub && (sub.status === 'submitted' || sub.status === 'done' || sub.status === 'complement');
        const dueDate = t.due_date ? new Date(t.due_date) : null;
        if (isDone) done.push({ ...t, subStatus: sub.status });
        else if (dueDate && dueDate < now) missing.push(t);
        else upcoming.push(t);
    });

    missing.sort((a, b) => new Date(a.due_date) - new Date(b.due_date));
    upcoming.sort((a, b) => new Date(a.due_date || '9999') - new Date(b.due_date || '9999'));
    done.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    container.innerHTML = `
    <ul class="nav nav-tabs todo-tabs mb-3"><li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-upcoming">Kommande (${upcoming.length})</button></li><li class="nav-item"><button class="nav-link text-danger" data-bs-toggle="tab" data-bs-target="#tab-missing">Saknas (${missing.length})</button></li><li class="nav-item"><button class="nav-link text-success" data-bs-toggle="tab" data-bs-target="#tab-done">Klara (${done.length})</button></li></ul>
    <div class="tab-content">
        <div class="tab-pane fade show active" id="tab-upcoming">${renderTaskList(upcoming, 'upcoming')}</div>
        <div class="tab-pane fade" id="tab-missing">${renderTaskList(missing, 'missing')}</div>
        <div class="tab-pane fade" id="tab-done">${renderTaskList(done, 'done')}</div>
    </div>`;
}
window.renderTodoList = renderTodoList;

function renderTaskList(tasks, type) {
    if (tasks.length === 0) return '<div class="text-center text-muted py-4 small">Inget här! 🎉</div>';
    let html = '<div class="d-flex flex-column gap-2">';
    tasks.forEach(t => {
        const tJson = JSON.stringify(t).replace(/"/g, '&quot;');
        let border = 'todo-' + type; let subInfo = t.course;
        if (type === 'done' && t.subStatus === 'done') subInfo += ' <i class="bi bi-check-circle-fill text-primary"></i>';
        html += `<div class="card p-3 shadow-sm todo-item ${border} cursor-pointer bg-white" onclick="openAssignmentModal(${tJson})"><div class="d-flex justify-content-between align-items-center"><div><div class="fw-bold">${t.title}</div><div class="text-muted small">${subInfo}</div></div><div class="text-end"><div class="small fw-bold ${type === 'missing' ? 'text-danger' : ''}">${t.due_date || 'Inget datum'}</div></div></div></div>`;
    });
    return html + '</div>';
}

/* =========================================
   3. INLÄMNINGSSYSTEM (MULTI-FILE & DRIVE)
   ========================================= */

async function openAssignmentModal(task) {
    if (window.setCurrentAssignmentId) window.setCurrentAssignmentId(task.id);
    currentAssignmentId = task.id;
    selectedFiles = []; // Nollställ fil-listan

    // UI Reset
    const mainView = document.getElementById('view-assignment-main');
    const editorView = document.getElementById('view-document-editor');
    if (mainView) mainView.style.opacity = '1';
    if (editorView) editorView.style.transform = 'translateX(100%)';
    document.getElementById('modal-work-card').style.display = 'block';
    document.getElementById('modal-grading-card').style.display = 'none';
    const editBtn = document.getElementById('btn-edit-assignment');
    if (editBtn) editBtn.style.display = 'none';

    document.getElementById('modal-title').innerText = task.title;
    document.getElementById('modal-desc').innerText = task.description || "";
    document.getElementById('modal-date').innerText = task.due_date ? "Inlämning: " + task.due_date : "Inget datum";

    // VISA LÄRARENS FILER (Nedladdningsbara)
    const attachArea = document.getElementById('modal-attachment-area');
    attachArea.innerHTML = '';
    if (task.attachments && Array.isArray(task.attachments)) {
        task.attachments.forEach(f => {
            const fJson = JSON.stringify(f).replace(/"/g, '&quot;');
            const icon = f.type === 'drive' ? '<img src="https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg" width="16">' : '<i class="bi bi-file-earmark-arrow-down text-danger"></i>';
            attachArea.innerHTML += `<div class="p-2 border rounded d-inline-flex align-items-center bg-light me-2 mb-2 cursor-pointer hover-effect" onclick="downloadRealFile(${fJson})"><div class="me-2">${icon}</div><div class="fw-bold small">${f.name}</div></div>`;
        });
    }

    const { data: sub } = await _supabase.from('submissions').select('*').eq('assignment_id', task.id).eq('student_name', currentUser.name).maybeSingle();
    window.currentDraftText = sub ? sub.submission_text : "";

    // Ladda in elevens filer
    if (sub && sub.submitted_files) {
        selectedFiles = sub.submitted_files;
    }

    const workCard = document.getElementById('modal-work-card');
    let workHtml = `<div class="card-body p-3"><h6 class="fw-bold mb-3">Ditt arbete</h6>`;

    let badgeText = "Tilldelad", badgeClass = "badge bg-light text-dark border mb-3";
    if (sub) {
        if (sub.status === 'draft') { badgeText = "Påbörjad"; badgeClass = "badge bg-info text-dark border mb-3"; }
        else if (sub.status === 'submitted') { badgeText = "Inlämnad"; badgeClass = "badge bg-success border mb-3"; }
        else if (sub.status === 'complement') { badgeText = "Komplettering"; badgeClass = "badge bg-warning text-dark border mb-3"; }
        else if (sub.status === 'done') { badgeText = "Godkänd"; badgeClass = "badge bg-primary border mb-3"; }
    }
    workHtml += `<div class="${badgeClass}">${badgeText}</div>`;

    if (sub && (sub.status === 'submitted' || sub.status === 'done' || sub.status === 'complement')) {
        // --- VISA INLÄMNAT ---
        workHtml += `<div class="file-preview-list mb-3">`;
        selectedFiles.forEach(f => {
            const fJson = JSON.stringify(f).replace(/"/g, '&quot;');
            let icon = f.type === 'drive' ? '<img src="https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg" width="16">' : '<i class="bi bi-file-earmark-check"></i>';
            workHtml += `<div class="file-preview-item border-0 bg-light cursor-pointer" onclick="downloadRealFile(${fJson})">${icon} <span class="ms-2 fw-bold small text-truncate">${f.name}</span></div>`;
        });
        if (sub.submission_text) workHtml += `<div class="p-2 bg-light border rounded text-muted small fst-italic"><i class="bi bi-file-text me-1"></i> Dokument skapat</div>`;
        workHtml += `</div>`;

        if (sub.status !== 'done') {
            workHtml += `<button class="btn btn-outline-danger w-100 btn-sm fw-bold mt-2" onclick="undoSubmit(${sub.id})">Ångra inlämning</button>`;
        }
    } else {
        // --- LÄMNA IN ---
        let hasDraft = sub && sub.status === 'draft' && sub.submission_text;
        workHtml += `
        <div class="d-grid gap-2 mb-3">
            <button class="btn ${hasDraft ? 'btn-outline-primary' : 'btn-outline-secondary'} text-start p-3 d-flex align-items-center justify-content-between shadow-sm" onclick="toggleEditorView(true)">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-file-text fs-5 text-primary"></i>
                    <div class="lh-1 text-start">
                        <div class="fw-bold small">${hasDraft ? 'Fortsätt skriva' : 'Skapa dokument'}</div>
                        <div class="text-muted" style="font-size:0.7rem;">${hasDraft ? 'Utkast sparat' : 'Google Docs-läge'}</div>
                    </div>
                </div>
                <i class="bi bi-chevron-right small text-muted"></i>
            </button>

            <div class="upload-drop-zone" id="drop-zone">
                <i class="bi bi-cloud-upload fs-1 text-muted mb-2"></i>
                <p class="small fw-bold mb-2">Dra & släpp filer här</p>
                <div class="d-flex gap-2 justify-content-center">
                    <button class="btn btn-sm btn-outline-secondary" onclick="document.getElementById('student-file-input').click()">Välj fil</button>
                    <button class="btn btn-sm drive-btn" onclick="openDrivePicker()"><img src="https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg" width="16"> Drive</button>
                </div>
                <input type="file" id="student-file-input" multiple class="d-none" onchange="handleFiles(this.files)">
            </div>
            
            <div id="selected-files-list" class="file-preview-list"></div>
        </div>

        <button class="btn btn-primary w-100 fw-bold py-2" onclick="submitAssignment(${task.id})">Lämna in</button>
        `;
    }

    workHtml += `</div>`;
    workCard.innerHTML = workHtml;

    const modal = new bootstrap.Modal(document.getElementById('assignmentModal'));
    modal.show();

    setupDragDrop();
    renderFileList();

    if (window.loadComments) window.loadComments(task.id);
}
window.openAssignmentModal = openAssignmentModal;

// --- FILHANTERING ELEV (BASE64) ---

function setupDragDrop() {
    const dropZone = document.getElementById('drop-zone');
    if (!dropZone) return;

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => { e.preventDefault(); e.stopPropagation(); }, false);
    });
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.add('drag-over'), false);
    });
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.remove('drag-over'), false);
    });

    dropZone.addEventListener('drop', (e) => handleFiles(e.dataTransfer.files), false);
}

async function handleFiles(files) {
    if (!files) return;
    const dropZone = document.getElementById('drop-zone');
    const orgHtml = dropZone.innerHTML;
    dropZone.innerHTML = '<div class="py-3"><div class="spinner-border spinner-border-sm text-primary"></div> Bearbetar...</div>';

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.size > 5000000) { alert(`"${file.name}" är för stor.`); continue; }
        try {
            const base64Data = await readFileToBase64(file);
            selectedFiles.push({
                name: file.name,
                type: 'file',
                size: (file.size / 1024).toFixed(1) + ' KB',
                data: base64Data // SPARA DATA
            });
        } catch (e) { console.error(e); }
    }
    dropZone.innerHTML = orgHtml;
    renderFileList();
}
window.handleFiles = handleFiles;

function openDrivePicker() {
    const fileName = prompt("Google Drive (Simulering):\nAnge namn:", "Min Uppsats.pdf");
    if (fileName) {
        selectedFiles.push({ name: fileName, type: 'drive', url: '#' });
        renderFileList();
    }
}
window.openDrivePicker = openDrivePicker;

function renderFileList() {
    const listEl = document.getElementById('selected-files-list');
    if (!listEl) return;
    listEl.innerHTML = '';

    selectedFiles.forEach((file, index) => {
        let icon = file.type === 'drive' ? '<img src="https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg" width="16">' : '<i class="bi bi-file-earmark"></i>';

        listEl.innerHTML += `
        <div class="file-preview-item">
            <div class="d-flex align-items-center gap-2 overflow-hidden">
                ${icon}
                <div class="text-truncate fw-bold">${file.name}</div>
            </div>
            <button class="btn btn-sm text-danger p-0" onclick="removeFile(${index})"><i class="bi bi-x-lg"></i></button>
        </div>`;
    });
}
window.renderFileList = renderFileList;

function removeFile(index) {
    selectedFiles.splice(index, 1);
    renderFileList();
}
window.removeFile = removeFile;

// --- REDIGERING & SPARA ---

function toggleEditorView(show) {
    const mainView = document.getElementById('view-assignment-main');
    const editorView = document.getElementById('view-document-editor');
    const docContent = document.getElementById('document-content');

    if (show) {
        docContent.innerHTML = window.currentDraftText || "Skriv ditt arbete här...";
        editorView.style.transform = 'translateX(0%)';
        if (autoSaveTimer) clearInterval(autoSaveTimer);
        autoSaveTimer = setInterval(() => saveDocument(true), 60000);
    } else {
        saveDocument(true).then(() => {
            editorView.style.transform = 'translateX(100%)';
            mainView.style.opacity = '1';
            if (autoSaveTimer) clearInterval(autoSaveTimer);
        });
    }
}
window.toggleEditorView = toggleEditorView;

async function saveDocument(keepOpen) {
    const content = document.getElementById('document-content').innerHTML;
    window.currentDraftText = content;
    const statusEl = document.getElementById('editor-save-status');
    if (statusEl) statusEl.innerText = "Sparar...";

    const { data: existing } = await _supabase.from('submissions').select('id, status').eq('assignment_id', currentAssignmentId).eq('student_name', currentUser.name).maybeSingle();

    let payload = { submission_text: content };
    // Om man lagt till filer, spara dem också vid autosave
    if (selectedFiles.length > 0) payload.submitted_files = selectedFiles;

    if (existing) {
        let newStatus = existing.status === 'complement' ? 'complement' : 'draft';
        await _supabase.from('submissions').update({ ...payload, status: newStatus }).eq('id', existing.id);
    } else {
        await _supabase.from('submissions').insert({
            assignment_id: currentAssignmentId, student_name: currentUser.name, status: 'draft', ...payload
        });
    }
    if (statusEl) statusEl.innerText = "Sparades " + new Date().toLocaleTimeString().slice(0, 5);
}
window.saveDocument = saveDocument;

// --- SUBMIT ---
async function submitAssignment(taskId) {
    const docContent = window.currentDraftText;

    if (selectedFiles.length === 0 && (!docContent || docContent.length < 10)) {
        alert("Ladda upp en fil eller skriv något!"); return;
    }

    const btn = document.querySelector('button[onclick*="submitAssignment"]');
    btn.innerText = "Skickar..."; btn.disabled = true;

    const { data: existing } = await _supabase.from('submissions').select('id').eq('assignment_id', taskId).eq('student_name', currentUser.name).maybeSingle();

    const payload = {
        status: 'submitted',
        submitted_files: selectedFiles,
        submission_text: docContent
    };

    try {
        if (existing) {
            await _supabase.from('submissions').update(payload).eq('id', existing.id);
        } else {
            await _supabase.from('submissions').insert({ assignment_id: taskId, student_name: currentUser.name, ...payload });
        }
        closeAssignmentModal();
        renderStudentClasswork();
    } catch (err) {
        alert("Filerna är för stora (Max ~5MB).");
        btn.innerText = "Lämna in"; btn.disabled = false;
    }
}
window.submitAssignment = submitAssignment;

function closeAssignmentModal() {
    const editor = document.getElementById('view-document-editor');
    if (editor && editor.style.transform === 'translateX(0%)') {
        saveDocument(true).then(() => { bootstrap.Modal.getInstance(document.getElementById('assignmentModal')).hide(); });
    } else {
        bootstrap.Modal.getInstance(document.getElementById('assignmentModal')).hide();
    }
}
window.closeAssignmentModal = closeAssignmentModal;

async function undoSubmit(subId) {
    if (confirm("Vill du ångra?")) {
        await _supabase.from('submissions').update({ status: 'draft' }).eq('id', subId);
        closeAssignmentModal();
        setTimeout(() => { _supabase.from('assignments').select('*').eq('id', currentAssignmentId).single().then(({ data }) => openAssignmentModal(data)); }, 300);
        renderStudentClasswork();
    }
}
window.undoSubmit = undoSubmit;

// ÖVRIGT
async function renderStudentStream() { if (window.renderCommonStream) window.renderCommonStream(); }
window.renderStudentStream = renderStudentStream;
async function renderStudentClasswork() {
    const list = document.getElementById('single-course-list'); list.innerHTML = '';
    const { data: tasks } = await _supabase.from('assignments').select('*').eq('course', currentCourse.name).neq('status', 'draft').order('due_date', { ascending: true });
    const { data: subs } = await _supabase.from('submissions').select('*').eq('student_name', currentUser.name);
    if (tasks) tasks.forEach(t => {
        if (t.target_students && t.target_students.length > 0 && !t.target_students.includes(currentUser.name)) return;
        const sub = subs ? subs.find(s => s.assignment_id === t.id) : null;
        let st = '<span class="text-muted small">Tilldelad</span>';
        if (sub) {
            if (sub.status === 'submitted') st = '<span class="text-success small fw-bold">Inlämnad</span>';
            if (sub.status === 'complement') st = '<span class="text-warning small fw-bold">Komplettering</span>';
            if (sub.status === 'done') st = '<span class="text-primary small fw-bold">Klar</span>';
            if (sub.status === 'draft') st = '<span class="text-info small fw-bold">Påbörjad</span>';
        }
        const j = JSON.stringify(t).replace(/"/g, '&quot;');
        list.innerHTML += `<div class="card border-0 border-bottom p-3 cursor-pointer hover-effect" onclick="openAssignmentModal(${j})"><div class="d-flex justify-content-between align-items-center"><div class="d-flex align-items-center gap-3"><div class="bg-light p-2 rounded-circle"><i class="bi bi-journal-text fs-5 text-secondary"></i></div><div class="fw-bold">${t.title}</div></div><div class="text-end"><div class="small">${st}</div></div></div></div>`;
    });
}
window.renderStudentClasswork = renderStudentClasswork;
async function renderStudentPeople() { if (window.renderCommonPeople) window.renderCommonPeople(); }
window.renderStudentPeople = renderStudentPeople;