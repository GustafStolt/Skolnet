console.log("🚀 LADDAR: teacher.js (MULTI-FILE UPLOAD)");

// Globala variabler
let editingAssignmentId = null;
let selectedCourseId = null;
let currentTaskObj = null;
let selectedTeacherFiles = []; // NY: Håller koll på lärarens filer

// =========================================================
// 1. NAVIGERING
// =========================================================

function initTeacherCourseView() { switchCourseTabTeacher('stream'); }
window.initTeacherCourseView = initTeacherCourseView;

function switchCourseTabTeacher(tab) {
    ['stream', 'classwork', 'people'].forEach(t => {
        document.getElementById('nav-' + t).className = 'course-nav-item';
        document.getElementById('course-tab-' + t).style.display = 'none';
    });
    document.getElementById('nav-' + tab).classList.add('active');
    document.getElementById('course-tab-' + tab).style.display = 'block';

    if (tab === 'stream') renderTeacherStream();
    if (tab === 'classwork') renderTeacherClasswork();
    if (tab === 'people') renderTeacherPeople();
}
window.switchCourseTabTeacher = switchCourseTabTeacher;


// =========================================================
// 2. KURS-HANTERING
// =========================================================

async function createCourse() {
    const name = document.getElementById('new-course-name').value;
    const theme = document.getElementById('new-course-theme').value;
    if (!name) { alert("Ange namn!"); return; }

    const btn = document.querySelector('#createCourseModal .btn-primary');
    const oldText = btn.innerText;
    btn.innerText = "Skapar..."; btn.disabled = true;

    try {
        const { error } = await _supabase.from('courses').insert({
            name: name, teacher: currentUser.name, theme: theme, target_class: '', is_archived: false
        });
        if (error) throw error;
        bootstrap.Modal.getInstance(document.getElementById('createCourseModal')).hide();
        document.getElementById('new-course-name').value = '';
        setTimeout(() => { if (window.renderCoursesGrid) window.renderCoursesGrid(); }, 500);
    } catch (err) { alert("Fel: " + err.message); }
    finally { btn.innerText = oldText; btn.disabled = false; }
}
window.createCourse = createCourse;

function prepareCourseOptions(id, name, archived) {
    selectedCourseId = id;
    document.getElementById('options-course-name').innerText = name;
    document.getElementById('btn-archive-course').style.display = archived ? 'none' : 'block';
    document.getElementById('btn-restore-course').style.display = archived ? 'block' : 'none';
    new bootstrap.Modal(document.getElementById('courseOptionsModal')).show();
}
window.prepareCourseOptions = prepareCourseOptions;

async function performArchive() {
    await _supabase.from('courses').update({ is_archived: true }).eq('id', selectedCourseId);
    bootstrap.Modal.getInstance(document.getElementById('courseOptionsModal')).hide();
    renderCoursesGrid();
}
window.performArchive = performArchive;

async function performRestore() {
    await _supabase.from('courses').update({ is_archived: false }).eq('id', selectedCourseId);
    bootstrap.Modal.getInstance(document.getElementById('courseOptionsModal')).hide();
    renderCoursesGrid();
}
window.performRestore = performRestore;

async function performDelete() {
    if (!confirm("VARNING: Detta raderar kursen permanent.")) return;
    const { error } = await _supabase.from('courses').delete().eq('id', selectedCourseId);
    if (error) alert("Kunde inte radera. Prova arkivera.");
    else {
        bootstrap.Modal.getInstance(document.getElementById('courseOptionsModal')).hide();
        renderCoursesGrid();
    }
}
window.performDelete = performDelete;


// =========================================================
// 3. UPPGIFTER (SKAPA & REDIGERA MED MULTI-FIL)
// =========================================================

async function renderTeacherClasswork() {
    const list = document.getElementById('single-course-list');
    list.innerHTML = '';
    document.getElementById('teacher-actions').innerHTML = `<button class="btn btn-primary btn-sm fw-bold" onclick="prepareCreateAssignment()"><i class="bi bi-plus-lg"></i> Skapa</button>`;

    const { data: tasks } = await _supabase.from('assignments').select('*').eq('course', currentCourse.name).order('created_at', { ascending: false });

    if (tasks) {
        tasks.forEach(t => {
            const tJson = JSON.stringify(t).replace(/"/g, '&quot;');
            let badges = '';
            if (t.status === 'draft') badges += '<span class="badge bg-secondary ms-2">Utkast</span>';
            if (t.status === 'scheduled') badges += '<span class="badge bg-info ms-2">Schemalagd</span>';

            list.innerHTML += `
            <div class="card border-0 border-bottom p-3 hover-effect cursor-pointer" onclick="openGradingModal(${tJson})">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-light p-2 rounded-circle"><i class="bi bi-journal-text"></i></div>
                        <div class="fw-bold">${t.title} ${badges}</div>
                    </div>
                    <small class="text-muted ms-3">${t.due_date ? 'Inlämning: ' + t.due_date : ''}</small>
                </div>
            </div>`;
        });
    }
}
window.renderTeacherClasswork = renderTeacherClasswork;

function prepareCreateAssignment() {
    editingAssignmentId = null;
    selectedTeacherFiles = []; // Nollställ fil-listan

    document.getElementById('new-assign-title').value = '';
    document.getElementById('new-assign-desc').value = '';
    document.getElementById('new-assign-date').value = '';

    const targetAll = document.getElementById('target-all');
    if (targetAll) targetAll.checked = true;
    toggleStudentSelector();

    // Nollställ fil-input
    document.getElementById('teacher-file-input').value = '';
    renderTeacherFileList();
    setupTeacherDragDrop();

    document.querySelector('#createAssignmentModal .modal-title').innerText = "Skapa uppgift";
    document.querySelector('#createAssignmentModal .btn-primary').innerHTML = `<i class="bi bi-send-fill me-2"></i> Publicera`;
    new bootstrap.Modal(document.getElementById('createAssignmentModal')).show();
}
window.prepareCreateAssignment = prepareCreateAssignment;

function startEditAssignment(task) {
    bootstrap.Modal.getInstance(document.getElementById('assignmentModal')).hide();
    editingAssignmentId = task.id;
    selectedTeacherFiles = [];

    document.getElementById('new-assign-title').value = task.title;
    document.getElementById('new-assign-desc').value = task.description || '';
    document.getElementById('new-assign-date').value = task.due_date || '';
    document.getElementById('new-assign-type').value = task.type;
    document.getElementById('new-assign-status').value = task.status;

    // Ladda in befintliga filer
    if (task.attachments && Array.isArray(task.attachments)) {
        selectedTeacherFiles = task.attachments;
    } else if (task.attachment_name) {
        selectedTeacherFiles.push({ name: task.attachment_name, type: 'file' });
    }
    renderTeacherFileList();
    setupTeacherDragDrop();

    toggleScheduleInput();
    document.querySelector('#createAssignmentModal .modal-title').innerText = "Redigera uppgift";
    document.querySelector('#createAssignmentModal .btn-primary').innerHTML = `<i class="bi bi-save me-2"></i> Uppdatera`;
    new bootstrap.Modal(document.getElementById('createAssignmentModal')).show();
}
window.startEditAssignment = startEditAssignment;

// --- FILHANTERING LÄRARE ---

function setupTeacherDragDrop() {
    const dropZone = document.getElementById('teacher-drop-zone');
    if (!dropZone) return;

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => { e.preventDefault(); e.stopPropagation(); }, false);
    });
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.add('drag-over'), false);
    });
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.remove('drag-over'), false);
    });
    dropZone.addEventListener('drop', (e) => handleTeacherFiles(e.dataTransfer.files), false);
}

function handleTeacherFiles(files) {
    if (!files) return;
    Array.from(files).forEach(file => {
        selectedTeacherFiles.push({
            name: file.name,
            type: 'file',
            size: (file.size / 1024).toFixed(1) + ' KB'
        });
    });
    renderTeacherFileList();
}
window.handleTeacherFiles = handleTeacherFiles;

function openTeacherDrivePicker() {
    const fileName = prompt("Google Drive (Lärare):\nAnge filnamn:", "Instruktioner.pdf");
    if (fileName) {
        selectedTeacherFiles.push({
            name: fileName,
            type: 'drive',
            url: '#'
        });
        renderTeacherFileList();
    }
}
window.openTeacherDrivePicker = openTeacherDrivePicker;

function renderTeacherFileList() {
    const list = document.getElementById('teacher-file-list');
    if (!list) return;
    list.innerHTML = '';

    selectedTeacherFiles.forEach((f, idx) => {
        const icon = f.type === 'drive'
            ? '<img src="https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg" width="16">'
            : '<i class="bi bi-file-earmark-text text-primary"></i>';

        list.innerHTML += `
        <div class="file-preview-item">
            <div class="d-flex align-items-center gap-2 overflow-hidden">
                ${icon} <span class="text-truncate fw-bold">${f.name}</span>
            </div>
            <button type="button" class="btn btn-sm text-danger p-0" onclick="removeTeacherFile(${idx})"><i class="bi bi-x-lg"></i></button>
        </div>`;
    });
}
window.renderTeacherFileList = renderTeacherFileList;

function removeTeacherFile(idx) {
    selectedTeacherFiles.splice(idx, 1);
    renderTeacherFileList();
}
window.removeTeacherFile = removeTeacherFile;


async function createAssignment() {
    const title = document.getElementById('new-assign-title').value;
    const type = document.getElementById('new-assign-type').value;
    const dateEl = document.getElementById('new-assign-date');
    const date = dateEl && dateEl.value ? dateEl.value : null;
    const desc = document.getElementById('new-assign-desc').value;
    const status = document.getElementById('new-assign-status').value;

    let targetStudents = null;
    const specEl = document.getElementById('target-specific');
    if (specEl && specEl.checked) {
        const checkboxes = document.querySelectorAll('.student-checkbox:checked');
        targetStudents = Array.from(checkboxes).map(cb => cb.value);
        if (targetStudents.length === 0) { alert("Välj minst en elev!"); return; }
    }

    if (!title) { alert("Ange titel!"); return; }

    const payload = {
        title, type, due_date: date, description: desc, status, target_students: targetStudents,
        course: currentCourse.name, class_name: currentCourse.target_class,
        attachments: selectedTeacherFiles // SPARA FILERNA
    };

    // Bakåtkompatibilitet: Spara första filen som attachment_name också
    if (selectedTeacherFiles.length > 0) {
        payload.attachment_name = selectedTeacherFiles[0].name;
    } else {
        payload.attachment_name = null;
    }

    const btn = document.querySelector('#createAssignmentModal .btn-primary');
    btn.innerText = "Sparar..."; btn.disabled = true;

    try {
        if (!editingAssignmentId) {
            const { error } = await _supabase.from('assignments').insert(payload);
            if (error) throw error;
            if (status === 'published') notifyNewAssignment(title, targetStudents);
        } else {
            const { error } = await _supabase.from('assignments').update(payload).eq('id', editingAssignmentId);
            if (error) throw error;
        }

        bootstrap.Modal.getInstance(document.getElementById('createAssignmentModal')).hide();
        renderTeacherClasswork();
        if (window.renderCommonStream) window.renderCommonStream();
    } catch (err) {
        console.error(err);
        alert("Fel vid sparande: " + err.message);
    } finally {
        btn.innerText = "Publicera"; btn.disabled = false;
    }
}
window.createAssignment = createAssignment;

// Bibliotek
async function openAssignmentLibrary() {
    bootstrap.Modal.getInstance(document.getElementById('createAssignmentModal')).hide();
    const libModal = new bootstrap.Modal(document.getElementById('libraryModal'));
    const list = document.getElementById('library-list');
    list.innerHTML = 'Laddar...';
    libModal.show();

    const { data: assignments } = await _supabase.from('assignments').select('*').order('created_at', { ascending: false }).limit(50);
    list.innerHTML = '';
    if (assignments && assignments.length > 0) {
        assignments.forEach(a => {
            const aJson = JSON.stringify(a).replace(/"/g, '&quot;');
            list.innerHTML += `<button class="list-group-item list-group-item-action p-3" onclick="importAssignment(${aJson})"><div class="d-flex justify-content-between"><h6 class="fw-bold text-primary">${a.title}</h6><small>${a.course}</small></div><p class="small text-truncate mb-0">${a.description || 'Ingen beskrivning'}</p></button>`;
        });
    } else { list.innerHTML = '<div class="p-3 text-center">Inget i biblioteket.</div>'; }
}
window.openAssignmentLibrary = openAssignmentLibrary;

function importAssignment(oldTask) {
    bootstrap.Modal.getInstance(document.getElementById('libraryModal')).hide();
    prepareCreateAssignment();
    document.getElementById('new-assign-title').value = oldTask.title + " (Kopia)";
    document.getElementById('new-assign-desc').value = oldTask.description || '';
    document.getElementById('new-assign-type').value = oldTask.type;
}
window.importAssignment = importAssignment;


// =========================================================
// 4. RÄTTNING & LIVE-DOKUMENT
// =========================================================

async function openGradingModal(task) {
    currentAssignmentId = task.id;
    currentTaskObj = task;
    editingAssignmentId = null;

    // UI RESET
    const mainView = document.getElementById('view-assignment-main');
    const editorView = document.getElementById('view-document-editor');
    if (mainView) mainView.style.opacity = '1';
    if (editorView) editorView.style.transform = 'translateX(100%)';

    document.getElementById('modal-work-card').style.display = 'none';
    document.getElementById('modal-grading-card').style.display = 'block';

    const editBtn = document.getElementById('btn-edit-assignment');
    editBtn.style.display = 'block';
    editBtn.onclick = () => startEditAssignment(task);

    const modal = new bootstrap.Modal(document.getElementById('assignmentModal'));
    document.getElementById('modal-title').innerText = task.title;
    document.getElementById('modal-desc').innerText = task.description || '';
    document.getElementById('modal-date').innerText = task.due_date ? 'Inlämning: ' + task.due_date : '';

    // VISA LÄRARENS BIFOGADE FILER
    const attachArea = document.getElementById('modal-attachment-area');
    attachArea.innerHTML = '';

    if (task.attachments && Array.isArray(task.attachments) && task.attachments.length > 0) {
        task.attachments.forEach(f => {
            const icon = f.type === 'drive' ? '<img src="https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg" width="16">' : '<i class="bi bi-file-earmark-text text-danger"></i>';
            attachArea.innerHTML += `<div class="p-2 border rounded d-inline-flex align-items-center bg-light me-2 mb-2 cursor-pointer" onclick="alert('Öppnar ${f.name}...')"><div class="me-2">${icon}</div><div class="fw-bold small">${f.name}</div></div>`;
        });
    } else if (task.attachment_name) {
        attachArea.innerHTML = `<div class="p-2 border rounded d-inline-flex align-items-center bg-light me-2 mb-2"><i class="bi bi-file-earmark-text text-danger me-2"></i><div class="fw-bold small">${task.attachment_name}</div></div>`;
    }


    const list = document.getElementById('grading-list');
    list.innerHTML = '<div class="p-3 text-center"><div class="spinner-border spinner-border-sm"></div></div>';
    modal.show();

    if (window.loadComments) window.loadComments(task.id);

    const { data: subs } = await _supabase.from('submissions').select('*').eq('assignment_id', task.id);

    let allNames = [];
    if (task.target_students && task.target_students.length > 0) {
        allNames = task.target_students;
    } else {
        const { data: s } = await _supabase.from('users').select('name').eq('class_name', currentCourse.target_class).eq('role', 'student');
        const { data: m } = await _supabase.from('course_members').select('user_name').eq('course_id', currentCourse.id);
        let set = new Set();
        if (s) s.forEach(x => set.add(x.name));
        if (m) m.forEach(x => set.add(x.user_name));
        allNames = Array.from(set);
    }

    list.innerHTML = '';
    if (allNames.length > 0) {
        allNames.sort();
        allNames.forEach(name => {
            const sub = subs.find(s => s.student_name === name);
            let badge = '<span class="badge bg-secondary">Ej påbörjad</span>';
            let actions = '';
            let contentLink = '';

            if (sub) {
                if (sub.status === 'submitted') badge = '<span class="badge bg-success">Inlämnad</span>';
                else if (sub.status === 'complement') badge = '<span class="badge bg-warning text-dark">Komplettering</span>';
                else if (sub.status === 'done') badge = '<span class="badge bg-primary">Klar</span>';
                else if (sub.status === 'draft') badge = '<span class="badge bg-info text-dark">Påbörjad</span>';

                // Elevens filer
                if (sub.submitted_files && Array.isArray(sub.submitted_files)) {
                    sub.submitted_files.forEach(f => {
                        let icon = f.type === 'drive' ? '<img src="https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg" width="12">' : '<i class="bi bi-paperclip"></i>';
                        contentLink += `<div class="small mt-1 text-truncate"><a href="#" onclick="alert('Öppnar ${f.name}...')">${icon} ${f.name}</a></div>`;
                    });
                } else if (sub.submitted_file) {
                    contentLink += `<div class="small mt-1 text-truncate"><a href="#" onclick="alert('Laddar ner ${sub.submitted_file}')"><i class="bi bi-paperclip"></i> ${sub.submitted_file}</a></div>`;
                }

                // Elevens Dokument
                if (sub.submission_text) {
                    const safeText = encodeURIComponent(sub.submission_text);
                    const btnText = sub.status === 'draft' ? 'Se utkast (Live)' : 'Visa dokument';
                    const icon = sub.status === 'draft' ? 'bi-eye' : 'bi-file-text';
                    contentLink += `<div class="mt-1"><button class="btn btn-sm btn-outline-primary py-0" style="font-size:0.75rem;" onclick="viewStudentDoc('${name}', '${safeText}')"><i class="bi ${icon} me-1"></i> ${btnText}</button></div>`;
                }

                if (sub.status !== 'draft' || sub.submission_text) {
                    actions = `
                    <div class="mt-2 d-flex gap-2 justify-content-end">
                        <button class="btn btn-xs btn-outline-warning" style="font-size:0.7rem;" onclick="setSubmissionStatus(${sub.id}, 'complement')">Komp.</button>
                        <button class="btn btn-xs btn-outline-success" style="font-size:0.7rem;" onclick="setSubmissionStatus(${sub.id}, 'done')">Godkänn</button>
                    </div>`;
                }
            }

            list.innerHTML += `
            <div class="list-group-item px-3 py-3">
                <div class="d-flex justify-content-between">
                    <div class="d-flex align-items-center">
                        <div class="bg-light rounded-circle border d-flex justify-content-center align-items-center me-3" style="width:35px;height:35px;">${name.charAt(0)}</div>
                        <div><div class="fw-bold">${name}</div>${contentLink}</div>
                    </div>
                    <div>${badge}</div>
                </div>
                ${actions}
            </div>`;
        });
    } else { list.innerHTML = '<div class="p-3 text-muted">Inga elever.</div>'; }
}
window.openGradingModal = openGradingModal;

function viewStudentDoc(studentName, encodedText) {
    const content = decodeURIComponent(encodedText);
    const editorView = document.getElementById('view-document-editor');
    const docContent = document.getElementById('document-content');

    docContent.innerHTML = content;
    docContent.contentEditable = "false";

    const toolbar = editorView.querySelector('.border-bottom.p-1.d-flex.gap-1');
    if (toolbar) toolbar.style.display = 'none';
    const saveBtn = editorView.querySelector('.btn-primary');
    if (saveBtn) saveBtn.style.display = 'none';

    const backBtn = editorView.querySelector('.btn-light.btn-sm.fw-bold.border');
    if (backBtn) {
        backBtn.onclick = () => {
            editorView.style.transform = 'translateX(100%)';
            if (toolbar) toolbar.style.display = 'flex';
            if (saveBtn) saveBtn.style.display = 'inline-block';
        };
    }
    editorView.style.transform = 'translateX(0%)';
}
window.viewStudentDoc = viewStudentDoc;

async function setSubmissionStatus(subId, newStatus) {
    const btn = event.target; btn.innerText = "...";

    const { data: sub } = await _supabase.from('submissions').select('student_name').eq('id', subId).single();
    const { error } = await _supabase.from('submissions').update({ status: newStatus }).eq('id', subId);

    if (!error) {
        let msg = newStatus === 'complement' ? `Komplettering krävs i ${currentCourse.name}` : `Godkänd i ${currentCourse.name}`;
        if (sub) sendNotification(sub.student_name, msg);
        if (currentTaskObj) openGradingModal(currentTaskObj);
    } else { alert("Fel vid statusändring"); }
}
window.setSubmissionStatus = setSubmissionStatus;


// =========================================================
// 5. INBJUDAN & NOTISER
// =========================================================

async function renderTeacherPeople() {
    document.getElementById('teacher-invite-action').innerHTML = `<button class="btn btn-sm btn-primary" onclick="new bootstrap.Modal(document.getElementById('inviteModal')).show()"><i class="bi bi-person-plus-fill"></i> Bjud in</button>`;
    const list = document.getElementById('people-list-students');
    list.innerHTML = '<div class="text-center py-3"><div class="spinner-border spinner-border-sm"></div></div>';

    const { data: members } = await _supabase.from('course_members').select('*').eq('course_id', currentCourse.id);
    list.innerHTML = '';

    if (members && members.length > 0) {
        members.sort((a, b) => a.user_name.localeCompare(b.user_name));
        members.forEach(m => {
            let roleBadge = m.role === 'teacher' ? '<span class="badge bg-info text-dark ms-2">Lärare</span>' : '';
            let classBadge = m.user_class ? `<span class="badge bg-light text-dark border ms-2">${m.user_class}</span>` : '';

            list.innerHTML += `
            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                <div class="d-flex align-items-center">
                    <div class="bg-secondary text-white rounded-circle d-flex justify-content-center align-items-center me-3" style="width:35px;height:35px;">${m.user_name.charAt(0)}</div>
                    <div><span class="fw-bold">${m.user_name}</span>${roleBadge}${classBadge}</div>
                </div>
                <button class="btn btn-sm text-danger" onclick="removeMember(${m.id})"><i class="bi bi-trash"></i></button>
            </div>`;
        });
    } else { list.innerHTML = '<div class="text-muted fst-italic py-3">Inga inbjudna.</div>'; }
}
window.renderTeacherPeople = renderTeacherPeople;

async function handleInviteSearch(query) {
    const list = document.getElementById('invite-search-results');
    if (query.length < 1) { list.style.display = 'none'; return; }
    const { data: users } = await _supabase.from('users').select('*').or(`name.ilike.%${query}%,class_name.ilike.%${query}%`);
    list.innerHTML = ''; list.style.display = 'block';
    if (!users || users.length === 0) { list.innerHTML = '<div class="p-3 text-muted">Inga träffar</div>'; return; }
    [...new Set(users.map(u => u.class_name))].filter(c => c && c.toLowerCase().includes(query.toLowerCase())).forEach(c => {
        list.innerHTML += `<div class="search-result-item" onclick="selectInviteTarget('${c}', 'class')"><div class="search-icon-box icon-class"><i class="bi bi-people-fill"></i></div><div><div class="fw-bold">Klass ${c}</div></div></div>`;
    });
    users.filter(u => u.name.toLowerCase().includes(query.toLowerCase())).forEach(u => {
        list.innerHTML += `<div class="search-result-item" onclick="selectInviteTarget('${u.name}', 'student')"><div class="search-icon-box icon-student"><i class="bi bi-person-fill"></i></div><div><div class="fw-bold">${u.name}</div><div class="small text-muted">${u.role}</div></div></div>`;
    });
}
window.handleInviteSearch = handleInviteSearch;

function selectInviteTarget(val, type) {
    document.getElementById('invite-final-value').value = val;
    document.getElementById('invite-final-type').value = type;
    document.getElementById('invite-search-input').style.display = 'none';
    document.getElementById('invite-search-results').style.display = 'none';
    document.getElementById('selected-invite-preview').style.display = 'block';
    document.getElementById('preview-text').innerText = val;
}
window.selectInviteTarget = selectInviteTarget;

function clearInviteSelection() {
    document.getElementById('invite-final-value').value = '';
    document.getElementById('invite-search-input').value = '';
    document.getElementById('invite-search-input').style.display = 'block';
    document.getElementById('selected-invite-preview').style.display = 'none';
}
window.clearInviteSelection = clearInviteSelection;
function resetInviteSearch() { clearInviteSelection(); }
window.resetInviteSearch = resetInviteSearch;

async function submitInvite() {
    const val = document.getElementById('invite-final-value').value;
    const type = document.getElementById('invite-final-type').value;
    const role = document.querySelector('input[name="inviteRole"]:checked').value;
    if (!val) { alert("Välj någon!"); return; }
    let members = [];
    if (type === 'class') {
        const { data: st } = await _supabase.from('users').select('name').eq('class_name', val).eq('role', 'student');
        if (st) members = st.map(s => ({ course_id: currentCourse.id, user_name: s.name, user_class: val, role: 'student' }));
    } else {
        members.push({ course_id: currentCourse.id, user_name: val, role: role });
    }
    const { error } = await _supabase.from('course_members').insert(members);
    if (error) alert("Kunde inte bjuda in.");
    else {
        members.forEach(m => sendNotification(m.user_name, `Inbjuden till ${currentCourse.name} som ${role}`));
        bootstrap.Modal.getInstance(document.getElementById('inviteModal')).hide();
        renderTeacherPeople();
        clearInviteSelection();
    }
}
window.submitInvite = submitInvite;

async function removeMember(id) {
    if (confirm("Ta bort?")) {
        await _supabase.from('course_members').delete().eq('id', id);
        renderTeacherPeople();
    }
}
window.removeMember = removeMember;

// Helpers
function toggleScheduleInput() { }
function toggleStudentSelector() {
    const spec = document.getElementById('target-specific').checked;
    document.getElementById('student-selector-box').style.display = spec ? 'block' : 'none';
    if (spec) loadStudentCheckboxes();
}
window.toggleStudentSelector = toggleStudentSelector;

async function loadStudentCheckboxes() {
    const box = document.getElementById('student-selector-box');
    box.innerHTML = 'Laddar...';
    const { data: s } = await _supabase.from('users').select('name').eq('class_name', currentCourse.target_class).eq('role', 'student');
    const { data: m } = await _supabase.from('course_members').select('user_name').eq('course_id', currentCourse.id);
    let set = new Set();
    if (s) s.forEach(x => set.add(x.name));
    if (m) m.forEach(x => set.add(x.user_name));
    box.innerHTML = '';
    Array.from(set).sort().forEach(n => {
        box.innerHTML += `<div class="form-check"><input class="form-check-input student-checkbox" type="checkbox" value="${n}" id="chk-${n}"><label class="form-check-label" for="chk-${n}">${n}</label></div>`;
    });
}

async function notifyNewAssignment(title, targets) {
    let users = [];
    if (targets && targets.length > 0) users = targets;
    else {
        const { data: s } = await _supabase.from('users').select('name').eq('class_name', currentCourse.target_class);
        const { data: m } = await _supabase.from('course_members').select('user_name').eq('course_id', currentCourse.id).eq('role', 'student');
        if (s) s.forEach(x => users.push(x.name));
        if (m) m.forEach(x => users.push(x.user_name));
    }
    [...new Set(users)].forEach(u => sendNotification(u, `Ny uppgift: ${title}`));
}

// Stream (Gemensam)
async function renderTeacherStream() {
    if (window.renderCommonStream) window.renderCommonStream();
}
window.renderTeacherStream = renderTeacherStream;

async function postToStream() {
    const input = document.getElementById('stream-post-content');
    if (!input.value.trim()) return;
    await _supabase.from('stream_posts').insert({
        course: currentCourse.name,
        author_name: currentUser.name,
        content: input.value.trim()
    });
    input.value = '';
    renderTeacherStream();
}
window.postToStream = postToStream;