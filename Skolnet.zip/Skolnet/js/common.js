console.log("🚀 LADDAR: common.js (FELSÄKER)");

// 1. CONFIG
const supabaseUrl = 'https://ejefyvscxxrscsclamtr.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVqZWZ5dnNjeHhyc2NzY2xhbXRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAwNjY5MDcsImV4cCI6MjA4NTY0MjkwN30.yHhwBwRMDLnjlunJJ6smKiiEwilKDPVLN3psW0t0v54';

let _supabase;
try {
    if (typeof supabase === 'undefined') {
        console.error("❌ FEL: Supabase-scriptet saknas i index.html!");
        alert("CRITICAL: Supabase script missing in index.html");
    } else {
        _supabase = supabase.createClient(supabaseUrl, supabaseKey);
        console.log("✅ Supabase ansluten.");
    }
} catch (e) {
    console.error("❌ KUNDE INTE STARTA DATABASEN:", e);
}

// Globala variabler
let currentUser = null;
let currentCourse = null;
let currentAssignmentId = null;
let allAssignments = [];
let mySubmissions = [];
let viewingArchived = false;
let currentCalendarDate = new Date();
let notifDropdownPlaceholder = null;
let notifDropdownOriginalParent = null;
const DEMO_UNEXCUSED_PERCENT = 8; // hårdkodat så du ser rött i ringen


// =========================================================
// 2. KOPPLA INLOGGNINGSKNAPPEN (Extremt viktig del!)
// =========================================================
document.addEventListener('DOMContentLoaded', () => {
    console.log("📄 DOMContentLoaded - Letar efter inloggningsknapp...");

    // Vi letar efter knappen BÅDE via ID och via hierarki för säkerhets skull
    const loginBtn = document.querySelector('#login-view button') || document.getElementById('login-btn');

    if (loginBtn) {
        console.log("🔘 Knapp hittad! Kopplar händelse...");

        // Ta bort gamla listeners genom att klona knappen
        const newBtn = loginBtn.cloneNode(true);
        loginBtn.parentNode.replaceChild(newBtn, loginBtn);

        // Lägg till klick-lyssnare med preventDefault
        newBtn.addEventListener('click', (e) => {
            console.log("🖱️ KNAPP TRYCKT!");
            e.preventDefault(); // <--- VIKTIGT: Stoppar sidan från att ladda om!
            handleLogin();
        });
    } else {
        console.error("❌ HITTAR INTE KNAPPEN! Kolla din HTML. Den ska ligga i #login-view");
    }
});


// 3. INLOGGNINGSFUNKTION
window.handleLogin = async function () {
    console.log("🚀 handleLogin() startar...");

    const userField = document.getElementById('login-username');
    const passField = document.getElementById('login-password');
    const errorEl = document.getElementById('login-error');
    const btn = document.querySelector('#login-view button');

    if (!userField || !passField) {
        console.error("❌ Hittar inte input-fälten (login-username/password)");
        return;
    }

    const userIn = userField.value.toLowerCase().trim();
    const passIn = passField.value;

    console.log(`👤 Försöker logga in: ${userIn}`);

    if (errorEl) errorEl.innerText = "";
    if (btn) btn.innerText = "Loggar in...";

    try {
        if (!_supabase) throw new Error("Databasen är inte ansluten.");

        // Anropa databasen
        const { data, error } = await _supabase
            .from('users')
            .select('*')
            .eq('username', userIn)
            .eq('password', passIn)
            .maybeSingle(); // Använd maybeSingle för att slippa 406-fel

        if (error) {
            console.error("DB Error:", error);
            throw error;
        }

        if (!data) {
            console.warn("⚠️ Ingen användare hittades med dessa uppgifter.");
            throw new Error("Fel användarnamn eller lösenord");
        }

        currentUser = data;
        currentUser.class_name = (currentUser.class_name || '').trim();

        console.log("✅ Inloggning lyckades! Roll:", currentUser.role);

        // Byt Vy
        const loginView = document.getElementById('login-view');
        const mainApp = document.getElementById('main-app');

        if (loginView) {
            loginView.classList.remove('d-flex'); // Om du använder bootstrap d-flex class
            loginView.style.display = 'none';
        }
        if (mainApp) mainApp.style.display = 'block';

        // Ladda data
        updateUI();
        fetchDashboardData();

        if (btn) btn.innerText = "Logga in";

    } catch (err) {
        console.error("❌ Inloggningsfel:", err);
        if (errorEl) errorEl.innerText = err.message;
        if (btn) btn.innerText = "Logga in";
    }
}

// 4. UI & NAVIGERING
function showView(viewId) {
    console.log(`Navigerar till: ${viewId}`);
    document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
    const target = document.getElementById(viewId + '-view');
    if (target) target.style.display = 'block';

    document.querySelectorAll('.nav-link, .mobile-nav-item').forEach(el => el.classList.remove('active'));
    if (event && event.currentTarget) event.currentTarget.classList.add('active');
}
window.showView = showView;

function toggleTheme() {
    const html = document.documentElement;
    html.setAttribute('data-bs-theme', html.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark');
}
window.toggleTheme = toggleTheme;

function updateUI() {
    if (!currentUser) return;
    try {
        // Desktop Sidebar
        const nameEl = document.getElementById('sidebar-name');
        const roleEl = document.getElementById('sidebar-role');
        const avatar = document.querySelector('.bg-primary.text-white.rounded-circle'); // Hitta avataren

        if (nameEl) nameEl.innerText = currentUser.name;
        if (roleEl) roleEl.innerText = currentUser.role === 'student' ? 'Elev' : 'Lärare';
        if (avatar) avatar.innerText = currentUser.name.charAt(0);

        // --- MOBIL HEADER FIX ---
        const mobUser = document.getElementById('mobile-username');
        const mobAv = document.getElementById('mobile-avatar');
        if (mobUser) mobUser.innerText = currentUser.name;
        if (mobAv) mobAv.innerText = currentUser.name.charAt(0);

        // Dölj lunch på lärare
        if (currentUser.role === 'teacher') {
            const lunch = document.getElementById('lunch-card');
            if (lunch) lunch.style.display = 'none';
        }
    } catch (e) { console.error("UI Update Error", e); }
}

// 5. DASHBOARD & DATA
async function fetchDashboardData() {
    // Lunch
    const { data: lunch } = await _supabase.from('lunch_menu').select('*').limit(1).maybeSingle();
    const lunchEl = document.getElementById('lunch-display');
    if (lunch && lunchEl) lunchEl.innerText = lunch.dish;
    else if (lunchEl) lunchEl.innerText = "Ingen lunchinfo";

    // Nästa lektion
    let query = _supabase.from('schedule').select('*').order('start_time', { ascending: true }).limit(1);
    if (currentUser.role === 'student') {
        if (currentUser.class_name) query = query.eq('class_name', currentUser.class_name);
    } else {
        query = query.eq('teacher', currentUser.name);
    }

    const { data } = await query.maybeSingle();
    const titleEl = document.getElementById('next-lesson-title');
    const infoEl = document.getElementById('next-lesson-info');
    const timeEl = document.getElementById('next-lesson-time');

    if (data) {
        if (titleEl) titleEl.innerText = data.course;
        const info = currentUser.role === 'student' ? `${data.room} • ${data.teacher}` : `Klass: ${data.class_name} • Sal: ${data.room}`;
        if (infoEl) infoEl.innerText = info;
        if (timeEl) timeEl.innerText = `${data.start_time.slice(0, 5)} - ${data.end_time.slice(0, 5)}`;
    } else {
        if (titleEl) titleEl.innerText = "Inga lektioner";
        if (infoEl) infoEl.innerText = "Just nu är det tomt i schemat.";
        if (timeEl) timeEl.innerText = "--:--";
    }
}

// 6. SMART SCHEMA
async function fetchSchedule() {
    if (!currentUser) return;
    ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'].forEach(day => {
        const el = document.getElementById(`col-${day}`);
        if (el) el.innerHTML = '';
    });
    const badge = document.getElementById('schedule-class-badge');
    if (badge) badge.innerText = currentUser.role === 'student' ? currentUser.class_name : "Mitt Lärarschema";

    // Hämta lektioner
    let cls = (currentUser.class_name || '').trim();
    let lessonQuery = _supabase.from('schedule').select('*');
    if (currentUser.role === 'student') lessonQuery = lessonQuery.eq('class_name', currentUser.class_name);
    else lessonQuery = lessonQuery.ilike('class_name', cls); // case-insensitive
    const { data: lessons } = await lessonQuery;

    // Hämta uppgifter (denna vecka)
    const today = new Date();
    const currentDay = today.getDay() || 7;
    const mondayDate = new Date(today);
    mondayDate.setDate(today.getDate() - (currentDay - 1));

    const weekDates = [];
    const dateToDayMap = {};
    const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];

    for (let i = 0; i < 5; i++) {
        let d = new Date(mondayDate);
        d.setDate(mondayDate.getDate() + i);
        // Använd YYYY-MM-DD
        const dateStr = d.toLocaleDateString('sv-SE');
        weekDates.push(dateStr);
        dateToDayMap[dateStr] = days[i];
    }

    const { data: assignments } = await _supabase.from('assignments').select('*').in('due_date', weekDates).neq('status', 'draft');

    const dayMap = { 'Monday': 'monday', 'Tuesday': 'tuesday', 'Wednesday': 'wednesday', 'Thursday': 'thursday', 'Friday': 'friday' };

    // Rita lektioner
    if (lessons) {
        lessons.forEach(l => {
            const colId = dayMap[l.day_of_week] ? `col-${dayMap[l.day_of_week]}` : null;
            renderScheduleItem(colId, l.start_time, l.end_time, l.course, l.room || '', "#cfe2ff", "#0d6efd", false, null);
        });
    }

    // Rita uppgifter
    if (assignments) {
        assignments.forEach(task => {
            if (currentUser.role === 'student') {
                const isMyClass = task.class_name === currentUser.class_name;
                let targeted = false;
                if (task.target_students && task.target_students.includes(currentUser.name)) targeted = true;
                if (!isMyClass && !targeted) return;
            }

            const dayName = dateToDayMap[task.due_date];
            if (!dayName) return;

            const colId = `col-${dayName}`;

            let startTime = "15:00", endTime = "16:00";
            if (task.scheduled_for) {
                const dt = new Date(task.scheduled_for);
                startTime = `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
                const endDt = new Date(dt.getTime() + 60 * 60000);
                endTime = `${String(endDt.getHours()).padStart(2, '0')}:${String(endDt.getMinutes()).padStart(2, '0')}`;
            }

            let bg = "#fff3cd", border = "#ffc107", icon = "";
            if (task.type === 'exam') { bg = "#f8d7da"; border = "#dc3545"; icon = "⚡ "; }
            else if (task.type === 'assignment') { bg = "#d1e7dd"; border = "#198754"; icon = "📝 "; }

            renderScheduleItem(colId, startTime, endTime, icon + task.title, "Klicka för info", bg, border, true, task);
        });
    }
}
window.fetchSchedule = fetchSchedule;

function renderScheduleItem(colId, start, end, title, subText, bg, border, isClickable, taskObj) {
    const colEl = document.getElementById(colId);
    if (!colEl || !start || !end) return;

    const startH = parseInt(start.split(':')[0]);
    const startM = parseInt(start.split(':')[1]);
    const endH = parseInt(end.split(':')[0]);
    const endM = parseInt(end.split(':')[1]);

    const top = (startH - 8) * 60 + startM;
    const height = ((endH * 60) + endM) - ((startH * 60) + startM);

    let clickAttr = "";
    let cursorClass = "";

    if (isClickable && taskObj) {
        const tJson = JSON.stringify(taskObj).replace(/"/g, '&quot;');
        if (currentUser.role === 'teacher') clickAttr = `onclick="openGradingModal(${tJson})"`;
        else clickAttr = `onclick="openAssignmentModal(${tJson})"`;
        cursorClass = "cursor-pointer hover-effect";
    }

    const styleExtra = isClickable ? "width: 85%; left: 10%; box-shadow: 2px 2px 5px rgba(0,0,0,0.2); z-index: 20;" : "width: 92%; left: 4%; z-index: 10;";

    colEl.innerHTML += `
    <div class="lesson-card-absolute ${cursorClass}" ${clickAttr} style="top: ${top}px; height: ${height}px; background-color: ${bg}; border-left: 3px solid ${border}; ${styleExtra}">
        <div class="fw-bold text-dark text-truncate" style="font-size:0.75rem;">${title}</div>
        <div class="text-muted" style="font-size: 0.7em;">${start} - ${end}</div>
        <div class="room-text text-muted" style="font-size: 0.7em;">${subText}</div>
    </div>`;
}

// 7. ÖVRIG LOGIK (Flikar, Kalender, Etc)
function switchAssignmentTab(tab) {
    ['courses', 'todo', 'calendar', 'single-course'].forEach(id => {
        const el = document.getElementById('panel-' + id);
        if (el) el.style.display = 'none';
    });
    if (tab !== 'single-course') {
        const target = document.getElementById('panel-' + tab);
        if (target) target.style.display = 'block';
        ['courses', 'todo', 'calendar'].forEach(t => {
            const btn = document.getElementById('tab-' + t);
            if (btn) btn.className = "btn btn-sm btn-light px-3";
        });
        document.getElementById('tab-' + tab).className = "btn btn-sm btn-light active fw-bold px-3";
    }
    if (tab === 'courses') renderCoursesGrid();
    if (tab === 'calendar') renderCalendar();
}
window.switchAssignmentTab = switchAssignmentTab;

// KURS-LISTA
async function renderCoursesGrid() {
    const grid = document.getElementById('courses-grid');
    if (!grid) return;

    const createBtnHtml = `<div class="col-md-6 col-lg-4"><div class="course-card shadow-sm d-flex flex-column justify-content-center align-items-center text-center p-4" style="border: 2px dashed #ccc; background: transparent; min-height: 200px;" onclick="new bootstrap.Modal(document.getElementById('createCourseModal')).show()"><div class="bg-light rounded-circle p-3 mb-3 text-primary"><i class="bi bi-plus-lg fs-2"></i></div><h5 class="fw-bold text-muted">Skapa Classroom</h5></div></div>`;

    grid.innerHTML = '<div class="col-12 text-center"><div class="spinner-border text-primary"></div></div>';
    let myCourses = [];

    if (currentUser.role === 'teacher') {
        const { data: owned } = await _supabase.from('courses').select('*').eq('teacher', currentUser.name);
        const { data: memberCourses } = await _supabase.from('course_members').select('course_id').eq('user_name', currentUser.name).eq('role', 'teacher');
        let coIds = [];
        if (memberCourses) coIds = memberCourses.map(m => m.course_id);
        let coOwned = [];
        if (coIds.length > 0) {
            const { data: co } = await _supabase.from('courses').select('*').in('id', coIds);
            coOwned = co || [];
        }
        myCourses = [...(owned || []), ...coOwned];
        myCourses.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        grid.innerHTML = `
        <div class="col-12 mb-3">
            <div class="btn-group shadow-sm" role="group">
                <button type="button" class="btn btn-sm ${!viewingArchived ? 'btn-primary fw-bold' : 'btn-light border'}" onclick="toggleCourseView(false)">Aktiva</button>
                <button type="button" class="btn btn-sm ${viewingArchived ? 'btn-primary fw-bold' : 'btn-light border'}" onclick="toggleCourseView(true)">Arkiverade</button>
            </div>
        </div>`;
    } else {
        const { data: mems } = await _supabase.from('course_members').select('course_id').eq('user_name', currentUser.name);
        const { data: mates } = await _supabase.from('courses').select('*').eq('target_class', currentUser.class_name);
        let ids = [];
        if (mems) ids = mems.map(m => m.course_id);
        if (mates) mates.forEach(c => ids.push(c.id));
        if (ids.length > 0) {
            const { data: c } = await _supabase.from('courses').select('*').in('id', [...new Set(ids)]);
            myCourses = c || [];
        }
        grid.innerHTML = '';
    }

    const visibleCourses = myCourses.filter(c => currentUser.role === 'student' ? !c.is_archived : c.is_archived === viewingArchived);

    if (currentUser.role === 'teacher' && !viewingArchived) grid.innerHTML += createBtnHtml;

    visibleCourses.forEach(c => {
        let subText = c.teacher === currentUser.name ? 'Du är ägare' : c.teacher;
        const cJson = JSON.stringify(c).replace(/"/g, '&quot;');
        const theme = c.theme.startsWith('theme-') ? c.theme.replace('theme-', 'bg-theme-') : c.theme;
        let settings = '';
        if (currentUser.role === 'teacher') settings = `<button class="course-settings-btn" onclick="event.stopPropagation(); prepareCourseOptions(${c.id}, '${c.name}', ${c.is_archived})"><i class="bi bi-gear-fill"></i></button>`;

        grid.innerHTML += `
        <div class="col-md-6 col-lg-4">
            <div class="course-card shadow-sm position-relative" style="${c.is_archived ? 'opacity:0.8;filter:grayscale(100%);' : ''}" onclick="openCourseCommon(${cJson})">
                ${settings}
                <div class="course-header ${theme}"><h4>${c.name}</h4><p>${subText}</p></div>
                <div class="course-body"><div class="text-muted small">${c.is_archived ? 'ARKIVERAD' : 'Öppna kurs'}</div></div>
            </div>
        </div>`;
    });
}
function toggleCourseView(show) { viewingArchived = show; renderCoursesGrid(); }
window.toggleCourseView = toggleCourseView;

function openCourseCommon(c) {
    currentCourse = c;
    document.getElementById('panel-courses').style.display = 'none';
    document.getElementById('panel-single-course').style.display = 'block';
    document.getElementById('single-course-title').innerText = c.name;
    document.getElementById('single-course-sub').innerText = currentUser.role === 'teacher' ? `Klass: ${c.target_class}` : c.teacher;
    document.getElementById('course-hero').className = `course-hero ${c.theme}`;
    if (currentUser.role === 'teacher') window.initTeacherCourseView();
    else window.initStudentCourseView();
}
window.openCourseCommon = openCourseCommon;
function switchCourseTabCommon(tab) {
    if (currentUser.role === 'teacher') window.switchCourseTabTeacher(tab);
    else window.switchCourseTabStudent(tab);
}
window.switchCourseTabCommon = switchCourseTabCommon;

async function renderCommonStream() {
    const list = document.getElementById('course-stream-list');
    if (!list) return;
    list.innerHTML = '';
    const postBox = document.getElementById('teacher-post-input');
    if (postBox) postBox.style.display = currentUser.role === 'teacher' ? 'block' : 'none';

    let q = _supabase.from('assignments').select('*').eq('course', currentCourse.name);
    if (currentUser.role === 'student') q = q.neq('status', 'draft');
    const { data: tasks } = await q;
    const { data: posts } = await _supabase.from('stream_posts').select('*').eq('course', currentCourse.name);

    let combined = [];
    if (tasks) tasks.forEach(t => combined.push({ ...t, isTask: true, sortTime: t.created_at }));
    if (posts) posts.forEach(p => combined.push({ ...p, isTask: false, sortTime: p.created_at }));
    combined.sort((a, b) => new Date(b.sortTime) - new Date(a.sortTime));

    if (combined.length > 0) {
        combined.forEach(item => {
            if (currentUser.role === 'student' && item.isTask && item.target_students && !item.target_students.includes(currentUser.name)) return;
            if (item.isTask) {
                const tJson = JSON.stringify(item).replace(/"/g, '&quot;');
                let click = currentUser.role === 'teacher' ? `openGradingModal(${tJson})` : `openAssignmentModal(${tJson})`;
                let badge = item.status === 'draft' ? '<span class="badge bg-secondary ms-2">Utkast</span>' : '';
                list.innerHTML += `<div class="card border shadow-sm p-3 d-flex flex-row align-items-center hover-effect cursor-pointer mb-3" onclick="${click}"><div class="bg-primary text-white rounded-circle d-flex justify-content-center align-items-center me-3" style="width:40px;height:40px;">${item.type === 'exam' ? '⚡' : '📝'}</div><div><div class="fw-bold">Ny uppgift: ${item.title} ${badge}</div><div class="text-muted small">${new Date(item.created_at).toLocaleDateString()}</div></div></div>`;
            } else {
                list.innerHTML += `<div class="card border shadow-sm p-3 mb-3"><div class="d-flex align-items-center mb-2"><div class="bg-secondary text-white rounded-circle d-flex justify-content-center align-items-center me-2" style="width:32px;height:32px;font-size:0.8rem;">${item.author_name.charAt(0)}</div><div><div class="fw-bold small">${item.author_name}</div><div class="text-muted" style="font-size:0.7rem;">${new Date(item.created_at).toLocaleDateString()}</div></div></div><div>${item.content}</div></div>`;
            }
        });
    } else { list.innerHTML = '<div class="text-center text-muted py-5">Välkommen! Inga inlägg.</div>'; }
}
window.renderCommonStream = renderCommonStream;

async function loadComments(assignId) {
    const container = document.getElementById('comments-container');
    if (!container) return;
    const { data } = await _supabase.from('task_comments').select('*').eq('assignment_id', assignId).order('created_at', { ascending: true });
    container.innerHTML = '';
    if (data) data.forEach(c => {
        const isMe = c.user_name === currentUser.name;
        container.innerHTML += `<div class="${isMe ? 'text-end' : 'text-start'} mb-2"><div class="d-inline-block p-2 rounded ${isMe ? 'bg-primary text-white' : 'bg-light text-dark'}" style="max-width:80%;font-size:0.9rem;">${c.text}</div></div>`;
    });
    container.scrollTop = container.scrollHeight;
}
window.loadComments = loadComments;

async function postComment() {
    const txt = document.getElementById('new-comment-input').value;
    if (!txt) return;
    document.getElementById('new-comment-input').value = '';
    await _supabase.from('task_comments').insert({ assignment_id: currentAssignmentId, user_name: currentUser.name, text: txt });
    loadComments(currentAssignmentId);
}
window.postComment = postComment;

async function fetchAssignmentsData() {
    let q = _supabase.from('assignments').select('*');
    if (currentUser.role === 'student') q = q.neq('status', 'draft');
    const { data } = await q;
    if (data) allAssignments = data;
}
window.fetchAssignmentsData = fetchAssignmentsData;

async function renderCalendar() {
    const grid = document.getElementById('calendar-grid');
    if (!grid) return;
    if (grid.innerHTML.trim() === "") grid.innerHTML = '<div class="p-5 text-center">Laddar kalender...</div>';
    if (allAssignments.length === 0) await fetchAssignmentsData();
    grid.innerHTML = '';

    const title = document.getElementById('calendar-month-year');
    if (title) { let m = currentCalendarDate.toLocaleString('sv-SE', { month: 'long' }); title.innerText = `${m.charAt(0).toUpperCase() + m.slice(1)} ${currentCalendarDate.getFullYear()}`; }

    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    let firstDay = new Date(year, month, 1).getDay();
    if (firstDay === 0) firstDay = 7;
    const days = new Date(year, month + 1, 0).getDate();

    for (let i = 1; i < firstDay; i++) grid.innerHTML += `<div class="calendar-day inactive"></div>`;
    const today = new Date();

    for (let d = 1; d <= days; d++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
        const tasks = allAssignments.filter(a => {
            if (a.due_date !== dateStr) return false;
            if (currentUser.role === 'student') {
                const isClass = a.class_name === currentUser.class_name;
                const targeted = a.target_students && a.target_students.includes(currentUser.name);
                if (!isClass && !targeted) return false;
            }
            return true;
        });
        const isToday = (d === today.getDate() && month === today.getMonth() && year === today.getFullYear()) ? 'today' : '';
        let html = '';
        tasks.forEach(t => {
            const tJson = JSON.stringify(t).replace(/"/g, '&quot;');
            let cls = 'chip-info'; if (t.type === 'exam') cls = 'chip-exam'; if (t.type === 'homework') cls = 'chip-homework';
            let click = currentUser.role === 'teacher' ? `openGradingModal(${tJson})` : `openAssignmentModal(${tJson})`;
            html += `<div class="assignment-chip ${cls}" onclick="event.stopPropagation(); ${click}">${t.title}</div>`;
        });
        grid.innerHTML += `<div class="calendar-day ${isToday}"><div class="day-number">${d}</div><div class="d-flex flex-column gap-1 overflow-hidden">${html}</div></div>`;
    }
}
window.renderCalendar = renderCalendar;
function changeMonth(s) { currentCalendarDate.setMonth(currentCalendarDate.getMonth() + s); renderCalendar(); }
window.changeMonth = changeMonth;
function changeCurrentMonth() { currentCalendarDate = new Date(); renderCalendar(); }
window.changeCurrentMonth = changeCurrentMonth;

// PLACEHOLDERS
async function renderTodoList() { document.getElementById('list-todo-pending').innerHTML = "Kommer snart..."; }
async function fetchGrades() {
    if (!currentUser) return;
    if (currentUser.role === 'teacher') { document.getElementById('grades-list').innerHTML = '<div class="alert alert-info">Under utveckling</div>'; return; }
    const { data } = await _supabase.from('grades').select('*').eq('student_name', currentUser.name);
    const c = document.getElementById('grades-list'); if (!c) return; c.innerHTML = '';
    if (data) data.forEach(i => {
        let bg = i.grade === 'A' ? 'bg-success' : (i.grade === 'F' ? 'bg-danger' : 'bg-primary');
        const iJson = JSON.stringify(i).replace(/"/g, '&quot;');
        c.innerHTML += `<div class="col-md-6"><div class="card h-100 border-0 shadow-sm p-4 grade-overview-card" onclick="openGradeMatrix(${iJson})"><div class="d-flex justify-content-between align-items-center"><div class="d-flex align-items-center gap-3"><div class="rounded-circle ${bg} text-white d-flex justify-content-center align-items-center" style="width:50px;height:50px;font-weight:bold;font-size:1.2rem;">${i.grade || '-'}</div><div><h5 class="fw-bold mb-0">${i.course}</h5><small class="text-muted">Klicka för matris</small></div></div>${i.course_warning ? '<i class="bi bi-exclamation-triangle-fill text-danger fs-5"></i>' : ''}</div></div></div>`;
    });
}
window.fetchGrades = fetchGrades;
function openGradeMatrix(item) {
    const m = new bootstrap.Modal(document.getElementById('gradeModal'));
    document.getElementById('grade-modal-course').innerText = `Betygsmatris: ${item.course}`;
    m.show();
}
window.openGradeMatrix = openGradeMatrix;
async function fetchAttendanceData() {
    if (!currentUser) return;

    // Lärare kan vi fixa senare – börjar med elevflödet
    if (currentUser.role === 'teacher') {
        document.getElementById('attendanceWeekAccordion').innerHTML =
            '<div class="alert alert-info">Lärarvy för närvaro kommer snart.</div>';
        return;
    }

    const accordion = document.getElementById('attendanceWeekAccordion');
    if (!accordion) return;

    accordion.innerHTML = '<div class="text-center py-4"><div class="spinner-border"></div></div>';

    const cls = (currentUser.class_name || '').trim();
    const today = new Date();
    const currentDay = today.getDay() || 7; // sön=7
    const monday = new Date(today);
    monday.setHours(0, 0, 0, 0);
    monday.setDate(today.getDate() - (currentDay - 1));

    // Mappar English->offset så vi kan räkna datum
    const dowToIndex = { Monday: 0, Tuesday: 1, Wednesday: 2, Thursday: 3, Friday: 4 };

    // 1) Hämta schema för klassen
    const { data: lessons, error: lessonErr } = await _supabase
        .from('schedule')
        .select('*')
        .eq('class_name', cls);

    if (lessonErr) {
        accordion.innerHTML = `<div class="alert alert-danger">Kunde inte hämta schema: ${lessonErr.message}</div>`;
        return;
    }

    // 2) Hämta frånvaro för veckan (elev)
    const weekDates = [];
    for (let i = 0; i < 5; i++) {
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        weekDates.push(d.toLocaleDateString('sv-SE')); // YYYY-MM-DD i sv-SE
    }

    const { data: absences, error: absErr } = await _supabase
        .from('attendance_records')
        .select('*')
        .eq('student_name', currentUser.name)
        .in('date', weekDates);

    if (absErr) {
        accordion.innerHTML = `<div class="alert alert-danger">Kunde inte hämta frånvaro: ${absErr.message}</div>`;
        return;
    }

    // Grupp: lessons per weekday
    const byDay = { Monday: [], Tuesday: [], Wednesday: [], Thursday: [], Friday: [] };
    (lessons || []).forEach(l => {
        const dow = (l.day_of_week || '').trim();
        if (byDay[dow]) byDay[dow].push(l);
    });

    // sortera per dag på starttid
    Object.keys(byDay).forEach(k => {
        byDay[k].sort((a, b) => (a.start_time || '').localeCompare(b.start_time || ''));
    });

    // Hjälp: datum för given day_of_week
    function getDateForDow(dow) {
        const idx = dowToIndex[dow];
        const d = new Date(monday);
        d.setDate(monday.getDate() + idx);
        return d.toLocaleDateString('sv-SE'); // YYYY-MM-DD
    }

    // Bygg UI
    const dayLabels = {
        Monday: "Måndag",
        Tuesday: "Tisdag",
        Wednesday: "Onsdag",
        Thursday: "Torsdag",
        Friday: "Fredag"
    };

    let html = '';
    Object.keys(byDay).forEach((dow, i) => {
        const dateStr = getDateForDow(dow);
        const dayLessons = byDay[dow];

        // Existerande frånvaro för just den dagen
        const absForDay = (absences || []).filter(a => a.date === dateStr);

        // Om hel dag redan anmäld
        const alreadyFullDay = absForDay.some(a => a.is_full_day);

        const collapseId = `att-day-${i}`;
        html += `
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button ${i === 0 ? '' : 'collapsed'}" type="button"
              data-bs-toggle="collapse" data-bs-target="#${collapseId}">
              <div class="d-flex w-100 justify-content-between align-items-center">
                <div><strong>${dayLabels[dow]}</strong> <span class="text-muted ms-2">${dateStr}</span></div>
                <div class="small">
                  ${alreadyFullDay ? '<span class="badge bg-success">Hel dag anmäld</span>' : ''}
                </div>
              </div>
            </button>
          </h2>
          <div id="${collapseId}" class="accordion-collapse collapse ${i === 0 ? 'show' : ''}">
            <div class="accordion-body">

              ${dayLessons.length === 0 ? `<div class="text-muted fst-italic">Inga lektioner.</div>` : `
                <div class="d-flex gap-2 flex-wrap mb-2">
  <button class="btn btn-outline-secondary btn-sm" type="button"
    onclick="attendanceSelectAll('${dow}', true)">Välj alla</button>
  <button class="btn btn-outline-secondary btn-sm" type="button"
    onclick="attendanceSelectAll('${dow}', false)">Avmarkera</button>

  <button class="btn btn-outline-secondary btn-sm" type="button"
    onclick="attendanceEnableDay('${dow}')">Avmarkera hel dag</button>

  <button class="btn btn-outline-danger btn-sm ms-auto" type="button"
    onclick="attendanceSelectFullDay('${dow}')">Anmäl hel dag</button>
</div>


                <div class="list-group mb-3">
                  ${dayLessons.map((l, idx) => {
            const key = attendanceMakeKey(l);
            const already = absForDay.some(a =>
                (a.day_of_week || '').trim() === (l.day_of_week || '').trim() &&
                (a.start_time || '').trim() === (l.start_time || '').trim() &&
                (a.end_time || '').trim() === (l.end_time || '').trim() &&
                (a.course || '').trim() === (l.course || '').trim()
            );

            return `
                      <label class="list-group-item d-flex align-items-center gap-2">
                        <input class="form-check-input me-1 attendance-chk attendance-${dow}"
                          type="checkbox"
                          value="${key}"
                          ${alreadyFullDay ? 'disabled' : ''}
                          ${already ? 'disabled checked' : ''}>
                        <div class="flex-grow-1">
                          <div class="fw-bold">${l.course}</div>
                          <div class="small text-muted">${l.start_time} - ${l.end_time}${l.room ? ` • Sal: ${l.room}` : ''}</div>
                        </div>
                        ${already ? '<span class="badge bg-success">Anmäld</span>' : ''}
                      </label>`;
        }).join('')}
                </div>
              `}

              <div class="mb-2">
                <label class="form-label fw-bold">Anledning (krävs)</label>
                <textarea class="form-control" id="attendance-reason-${dow}" rows="2"
                  placeholder="Skriv varför du är frånvarande..."></textarea>
              </div>

              <button class="btn btn-primary w-100 fw-bold"
                onclick="submitAbsenceForDay('${dow}', '${dateStr}')">
                Skicka frånvaroanmälan
              </button>

            </div>
          </div>
        </div>
        `;
    });

    accordion.innerHTML = html;

    // ====== Diagram-beräkning (3 färger) ======
    const totalLessons = Object.values(byDay).reduce((sum, arr) => sum + arr.length, 0);

    // 1) excused: lektioner anmälda
    const lessonAbs = (absences || []).filter(a => !a.is_full_day).length;

    // 2) full-day => räkna som alla lektioner den dagen
    let fullDayLessonCount = 0;
    const fullDays = new Set((absences || []).filter(a => a.is_full_day).map(a => (a.day_of_week || '').trim()));
    fullDays.forEach(dow => fullDayLessonCount += (byDay[dow] || []).length);

    const excusedLessons = Math.min(totalLessons, lessonAbs + fullDayLessonCount);

    // Om totalLessons är 0, visa 100% närvaro
    if (totalLessons === 0) {
        setAttendanceRing(100, 0, 0);
        return;
    }

    // 3) demo unexcused (hårdkodat procent)
    const unexcusedPct = Math.max(0, Math.min(100, DEMO_UNEXCUSED_PERCENT));

    // 4) excused procent baserat på antal lektioner
    const excusedPct = Math.round((excusedLessons / totalLessons) * 100);

    // 5) present = resterande
    let presentPct = 100 - excusedPct - unexcusedPct;
    if (presentPct < 0) presentPct = 0;

    // Räkna om så de blir 100 om det behövs
    setAttendanceRing(presentPct, excusedPct, unexcusedPct);

}
window.fetchAttendanceData = fetchAttendanceData;



// --- helpers (lägg under) ---
function attendanceMakeKey(lesson) {
    // unik nyckel för checkboxen (inkl times för att skilja dubbla pass)
    const course = (lesson.course || '').replaceAll('|', '/');
    const dow = (lesson.day_of_week || '').replaceAll('|', '/');
    const st = (lesson.start_time || '').replaceAll('|', '/');
    const et = (lesson.end_time || '').replaceAll('|', '/');
    const room = (lesson.room || '').replaceAll('|', '/');
    return `${dow}|${st}|${et}|${course}|${room}`;
}

function attendanceEnableDay(dow) {
    document.querySelectorAll(`.attendance-${dow}`).forEach(chk => {
        chk.disabled = false;
        chk.checked = false;
    });
}
window.attendanceEnableDay = attendanceEnableDay;


function attendanceParseKey(key) {
    const [day_of_week, start_time, end_time, course, room] = key.split('|');
    return { day_of_week, start_time, end_time, course, room };
}

function attendanceSelectAll(dow, on) {
    document.querySelectorAll(`.attendance-${dow}`).forEach(chk => {
        if (!chk.disabled) chk.checked = on;
    });
}
window.attendanceSelectAll = attendanceSelectAll;

function attendanceSelectFullDay(dow) {
    // Markera alla för dagen (om inte redan disabled)
    attendanceSelectAll(dow, true);
}
window.attendanceSelectFullDay = attendanceSelectFullDay;

async function submitAbsenceForDay(dow, dateStr) {
    if (!currentUser) return;

    const reasonEl = document.getElementById(`attendance-reason-${dow}`);
    const reason = (reasonEl?.value || '').trim();

    if (reason.length < 5) {
        alert("Skriv en anledning (minst 5 tecken).");
        return;
    }

    const checks = Array.from(document.querySelectorAll(`.attendance-${dow}:checked`))
        .filter(chk => !chk.disabled);

    // Om man inte valt något -> blocka (du kan ändra till hel-dag default om du vill)
    if (checks.length === 0) {
        alert("Välj minst en lektion (eller välj alla / hel dag).");
        return;
    }

    const cls = (currentUser.class_name || '').trim();

    // Om användaren har markerat alla dagens lektioner => spara som hel dag + (valfritt) även lektioner
    // Jag sparar EN rad som "hel dag" för att det ska bli snyggt i historiken.
    const allForDay = Array.from(document.querySelectorAll(`.attendance-${dow}`)).filter(c => !c.disabled);
    const isFullDay = allForDay.length > 0 && checks.length === allForDay.length;

    const payload = [];

    if (isFullDay) {
        payload.push({
            student_name: currentUser.name,
            class_name: cls,
            date: dateStr,
            status: 'excused',            // "godkänd" direkt när anledning finns
            reason: reason,
            is_full_day: true,
            day_of_week: dow
        });
    } else {
        checks.forEach(chk => {
            const info = attendanceParseKey(chk.value);
            payload.push({
                student_name: currentUser.name,
                class_name: cls,
                date: dateStr,
                status: 'excused',         // godkänd direkt när anledning finns
                reason: reason,
                is_full_day: false,
                day_of_week: info.day_of_week,
                start_time: info.start_time,
                end_time: info.end_time,
                course: info.course,
                room: info.room
            });
        });
    }

    const btn = event?.target;
    const old = btn?.innerText;
    if (btn) { btn.innerText = "Skickar..."; btn.disabled = true; }

    const { error } = await _supabase.from('attendance_records').insert(payload);

    if (btn) { btn.innerText = old || "Skicka frånvaroanmälan"; btn.disabled = false; }

    if (error) {
        console.error(error);
        alert("Kunde inte anmäla frånvaro: " + error.message);
        return;
    }

    alert("Frånvaroanmälan skickad ✅");
    fetchAttendanceData(); // refresh
}
window.submitAbsenceForDay = submitAbsenceForDay;


function setAttendanceRing(present, excused, unexcused) {
    // clamp
    present = Math.max(0, Math.min(100, present));
    excused = Math.max(0, Math.min(100, excused));
    unexcused = Math.max(0, Math.min(100, unexcused));

    // normalisera om de inte summerar 100
    const sum = present + excused + unexcused;
    if (sum !== 100 && sum > 0) {
        present = Math.round(present * 100 / sum);
        excused = Math.round(excused * 100 / sum);
        unexcused = 100 - present - excused;
    }

    const ring = document.getElementById('attendance-circle');
    const center = document.getElementById('attendance-percentage');

    if (ring) {
        ring.style.setProperty('--p-green', present + '%');
        ring.style.setProperty('--p-yellow', excused + '%');
        // red segment blir resten automatiskt
    }

    // i mitten visar vi närvaro (kan ändras om du vill visa något annat)
    if (center) center.innerText = present + "%";

    const excEl = document.getElementById('pct-excused');
    const unxEl = document.getElementById('pct-unexcused');
    const preEl = document.getElementById('pct-present');

    if (excEl) excEl.innerText = excused + "%";
    if (unxEl) unxEl.innerText = unexcused + "%";
    if (preEl) preEl.innerText = present + "%";
}


/* =========================================
   NOTIS-SYSTEM (FIXAD & FELSÄKER)
   ========================================= */

// 1. Hämta notiser
async function fetchNotifications() {
    // Säkerställ att vi är inloggade och har DB
    if (!currentUser || !_supabase) return;

    const { data } = await _supabase
        .from('notifications')
        .select('*')
        .eq('user_name', currentUser.name)
        .eq('is_read', false)
        .order('created_at', { ascending: false });

    const badge = document.getElementById('notif-badge');
    const list = document.getElementById('notification-list');
    // I fetchNotifications()...
    // Hitta mobil-badgen också
    const mobileBadge = document.getElementById('mobile-notif-badge');

    if (data && data.length > 0) {
        // ... (samma kod för desktop badge)
        if (mobileBadge) { mobileBadge.innerText = data.length; mobileBadge.style.display = 'block'; }
    } else {
        // ...
        if (mobileBadge) mobileBadge.style.display = 'none';
    }

    if (!badge || !list) return;

    if (data && data.length > 0) {
        badge.innerText = data.length;
        badge.style.display = 'block';

        list.innerHTML = '';
        data.forEach(n => {
            // Snyggare tidsformat
            const time = new Date(n.created_at).toLocaleTimeString().slice(0, 5);
            const date = new Date(n.created_at).toLocaleDateString();

            list.innerHTML += `
            <div class="p-2 border-bottom hover-effect bg-white cursor-pointer" onclick="readNotification(${n.id})">
                <div class="small fw-bold text-dark">${n.message}</div>
                <div class="text-muted d-flex justify-content-between mt-1" style="font-size:0.65rem;">
                    <span>${date}</span><span>${time}</span>
                </div>
            </div>`;
        });
    } else {
        badge.style.display = 'none';
        list.innerHTML = '<div class="p-4 text-center text-muted small fst-italic">Inga nya notiser 🎉</div>';
    }
}
// Körs automatiskt var 15:e sekund
setInterval(fetchNotifications, 15000);

// 2. Öppna/Stäng meny
function toggleNotifications(e) {
    if (e) e.stopPropagation();

    const dd = document.getElementById('notification-dropdown');
    const bell = document.getElementById('notif-bell-container');
    if (!dd || !bell) return;

    const isHidden = dd.style.display === 'none' || dd.style.display === '';

    if (isHidden) {
        // --- Flytta dropdownen till <body> så inget kan klippa den ---
        if (!notifDropdownPlaceholder) {
            notifDropdownOriginalParent = dd.parentElement;
            notifDropdownPlaceholder = document.createElement('div');
            notifDropdownPlaceholder.id = 'notif-dd-placeholder';
            notifDropdownOriginalParent.insertBefore(notifDropdownPlaceholder, dd);
            document.body.appendChild(dd);
        }

        // --- Positionera exakt under klockan ---
        const r = bell.getBoundingClientRect();
        const width = 280;

        // clamp så den aldrig hamnar utanför skärmen
        const left = Math.min(Math.max(8, r.left), window.innerWidth - width - 8);
        const top = Math.min(r.bottom + 8, window.innerHeight - 120); // 120 = lite marginal

        dd.style.position = 'fixed';
        dd.style.left = `${Math.round(left)}px`;
        dd.style.top = `${Math.round(top)}px`;
        dd.style.width = `${width}px`;

        // super-viktigt: nollställ bootstrap/inline som kan förstöra
        dd.style.right = 'auto';
        dd.style.bottom = 'auto';
        dd.style.transform = 'none';
        dd.style.inset = 'auto';
        dd.style.margin = '0';
        dd.style.zIndex = '99999';
        dd.style.display = 'block';
        dd.style.visibility = 'visible';
        dd.style.opacity = '1';

        fetchNotifications();
    } else {
        dd.style.display = 'none';

        // --- Flytta tillbaka dropdownen där den låg från början ---
        if (notifDropdownPlaceholder && notifDropdownOriginalParent) {
            notifDropdownOriginalParent.insertBefore(dd, notifDropdownPlaceholder);
        }
    }
}
window.toggleNotifications = toggleNotifications;

// 3. Stäng om man klickar utanför 
/*
window.addEventListener('click', () => {
    const dd = document.getElementById('notification-dropdown');
    if (!dd) return;

    if (dd.style.display === 'block') {
        dd.style.display = 'none';
        if (notifDropdownPlaceholder && notifDropdownOriginalParent) {
            notifDropdownOriginalParent.insertBefore(dd, notifDropdownPlaceholder);
        }
    }
}); */


// 4. Markera som läst
async function readNotification(id) {
    await _supabase.from('notifications').update({ is_read: true }).eq('id', id);
    fetchNotifications(); // Uppdatera listan direkt
}
window.readNotification = readNotification;

async function markAllRead() {
    await _supabase.from('notifications').update({ is_read: true }).eq('user_name', currentUser.name);
    fetchNotifications();
}
window.markAllRead = markAllRead;

// 5. SKICKA NOTIS (Denna saknades och kraschade lärarvyn!)
async function sendNotification(targetUser, msg, link = null) {
    if (!_supabase) return;
    try {
        await _supabase.from('notifications').insert({
            user_name: targetUser,
            message: msg,
            link: link
        });
    } catch (err) {
        console.error("Kunde inte skicka notis:", err);
    }
}
window.sendNotification = sendNotification;

let notifOutsideHandler = null;

function openNotifDropdown() {
    const dd = document.getElementById('notification-dropdown');
    const bell = document.getElementById('notif-bell-container');
    if (!dd || !bell) return;

    const r = bell.getBoundingClientRect();
    const width = 280;

    // clamp så den alltid hamnar på skärmen
    const left = Math.min(Math.max(8, r.left), window.innerWidth - width - 8);
    const top = Math.min(r.bottom + 8, window.innerHeight - 140);

    dd.style.left = `${Math.round(left)}px`;
    dd.style.top = `${Math.round(top)}px`;
    dd.style.width = `${width}px`;
    dd.style.display = 'block';

    fetchNotifications();

    // Stoppa att klick inne i dropdown stänger den
    dd.onclick = (ev) => ev.stopPropagation();

    // Outside click: lägg på EFTER att öppningsklicket är klart
    if (!notifOutsideHandler) {
        notifOutsideHandler = (ev) => {
            const insideDropdown = ev.target.closest('#notification-dropdown');
            const onBell = ev.target.closest('#notif-bell-container');
            if (insideDropdown || onBell) return;
            closeNotifDropdown();
        };
        setTimeout(() => document.addEventListener('click', notifOutsideHandler), 0);
    }
}

function closeNotifDropdown() {
    const dd = document.getElementById('notification-dropdown');
    if (dd) dd.style.display = 'none';

    if (notifOutsideHandler) {
        document.removeEventListener('click', notifOutsideHandler);
        notifOutsideHandler = null;
    }
}

function toggleNotifications(e) {
    if (e) e.stopPropagation();
    const dd = document.getElementById('notification-dropdown');
    if (!dd) return;

    if (dd.style.display === 'block') closeNotifDropdown();
    else openNotifDropdown();
}
window.toggleNotifications = toggleNotifications;

window.addEventListener('resize', closeNotifDropdown);
window.addEventListener('scroll', closeNotifDropdown, true); // true = fångar scroll i sidebar också



function toggleNotifications(e) {
    if (e) e.stopPropagation();

    const dd = document.getElementById('notification-dropdown');
    if (!dd) return;

    const isOpen = dd.style.display === 'block';
    if (isOpen) closeNotifDropdown();
    else openNotifDropdown();
}
window.toggleNotifications = toggleNotifications;

// Bonus: om man resizear fönstret, stäng dropdownen (förhindrar “fel position”)
window.addEventListener('resize', () => closeNotifDropdown());


/* =========================================
   RIKTIG FILHANTERING (BASE64)
   ========================================= */

// Hjälpfunktion för att läsa in en fil till Base64 (För uppladdning)
function readFileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}
window.readFileToBase64 = readFileToBase64;

// Hjälpfunktion för att ladda ner en Base64-fil (För nedladdning)
function downloadRealFile(fileObj) {
    if (!fileObj.data) {
        alert("Fel: Denna fil saknar data (kanske en gammal simulerad fil?).");
        return;
    }

    // Skapa en temporär länk
    const link = document.createElement("a");
    link.href = fileObj.data; // Detta är base64-strängen (data:image/png;base64...)
    link.download = fileObj.name; // Filnamnet

    // Tvinga klick
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
window.downloadRealFile = downloadRealFile;

/* =========================================
   MOBIL-SPECIFIKA FUNKTIONER (Fix för ReferenceError)
   ========================================= */

// 1. Hantera aktiv klass på mobilmenyn
function updateMobileNav(element) {
    // Ta bort 'active' från alla ikoner
    document.querySelectorAll('.mobile-nav-item').forEach(el => el.classList.remove('active'));
    // Lägg till 'active' på den vi klickade på
    if (element) element.classList.add('active');
}
// Gör funktionen tillgänglig för HTML
window.updateMobileNav = updateMobileNav;

// 2. Hantera mobil-aviseringar (Dropdown)
function toggleMobileNotifications(e) {
    if (e) e.stopPropagation(); // Stoppa klicket från att stänga direkt

    const dd = document.getElementById('mobile-notification-dropdown');
    if (!dd) return;

    // Kolla om den är dold
    const isHidden = dd.style.display === 'none' || dd.style.display === '';

    // Stäng alla andra menyer först för att undvika krockar
    document.querySelectorAll('.dropdown-menu').forEach(d => d.style.display = 'none');

    if (isHidden) {
        dd.style.display = 'block';
        if (window.fetchNotifications) window.fetchNotifications(); // Hämta nya notiser

        // Synka listan från desktop till mobil om den redan finns
        setTimeout(() => {
            const desktopList = document.getElementById('notification-list');
            const mobileList = document.getElementById('mobile-notification-list');
            if (desktopList && mobileList && desktopList.innerHTML.trim() !== "") {
                mobileList.innerHTML = desktopList.innerHTML;
            }
        }, 100);
    } else {
        dd.style.display = 'none';
    }
}
window.toggleMobileNotifications = toggleMobileNotifications;

// Stäng mobil-menyn om man klickar utanför (på skärmen)
window.addEventListener('click', (e) => {
    const mdd = document.getElementById('mobile-notification-dropdown');
    if (mdd && mdd.style.display === 'block') {
        mdd.style.display = 'none';
    }
});